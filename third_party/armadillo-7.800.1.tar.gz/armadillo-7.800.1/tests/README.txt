- The tests in this directory are intended to be run only on Linux or Mac OS X
- The tests are a work-in-progress
- Armadillo must be installed before the tests can be compiled
- C++11 compiler is required to compile the tests
- To compile the tests, use "make"
- Run the tests by running the "main" executable

Example:

make clean
make
./main

