% BURBLE    Set the sparse monitor flag to extremely verbose.
spparms('spumoni', 3);